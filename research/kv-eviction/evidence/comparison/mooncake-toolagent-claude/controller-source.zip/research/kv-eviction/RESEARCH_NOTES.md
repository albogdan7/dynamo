# KV eviction: detailed research notes

Preserved from the longer plan on 2026-10-28. These are supporting notes, not the current implementation contract. See [the concise plan](PLAN.md) for current scope, commands and naming.

# KV eviction agent experiments

Started: 2026-10-28. This is the durable task plan; retain it with the experiment report. The canonical plan is tracked in this fork at `research/kv-eviction/PLAN.md`.

## Objective

On a new branch of the Dynamo fork, provide one readable command that runs a sandboxed Claude Code or Codex experiment, preserves every submitted policy and score, and supports additional public traces through a small loader. Verify the command with real model runs, not only mocks. Use descriptive names such as baseline, LRU, and LRU with leaf-first tiebreak; do not name experiments after a person.

## Starting point

- Fork: https://github.com/albogdan7/dynamo
- Pinned baseline: dc61f2bbfbed0de800a7b2399188be82737f5bd0.
- Preserve the existing synthetic simulator's results before extending it. The current policy is LRU with a newest-creation tiebreak.
- All work belongs to the fork checkout on `research/agent-eviction-experiments`. Do not modify other projects.

## Plan

1. Reproduce the original baseline command twice, then compare plain LRU and LRU with leaf-first tiebreak on the exact original seeds and cache size. Save raw outputs and explain numerical differences rather than rounding them away.
2. Research primary trace releases. Prefer Mooncake conversation and tool/agent traces because they preserve reusable prefix block identities; length-only traces cannot reconstruct cache reuse. Pin source revisions, record licenses and SHA-256 checksums, and keep downloads separate from code.
3. Define a versioned JSONL block-trace format: metadata records block size and provenance; requests record arrival time, input/output lengths, and ordered reusable block identities. Preserve hash identities rather than inventing token text. Validate malformed inputs and handle partial blocks explicitly.
4. Implement a small loader for the native format and official Mooncake JSONL. Preserve the legacy synthetic path for exact reproduction; document any simulator differences needed for real prefix hashes.
5. Implement a standard-library command-line controller for Claude Code and Codex. Use each CLI's supported sandbox, isolated work directories, a fixed submission budget and timeouts. The trusted controller owns scoring and archives immutable policy snapshots. Give the agent tuning feedback; score independent held-out data only after selection. Never silently fall back to unsandboxed execution.
6. Save run metadata (commit, CLI/model, full command, prompt, budgets, trace checksums, cache size), agent transcripts, every policy and tuning score, selected-policy held-out scores, and failures. Keep run artifacts outside ignored timestamp-only results. Make retrieval an explicit output path.
7. Establish a documented serving timing model before adding ITL/goodput. Model arrivals, queueing, prefill, decode and scheduling sufficiently to emit token timestamps. Prefer an existing validated implementation where practical; otherwise hand-check the smallest transparent event simulator. Keep legacy reproduction separate from the new serving model.
8. Verify behavior with a few meaningful tests and readable manual commands: original reproduction, public trace import, identical replay, invalid inputs/policies, budget/timeout behavior, sandbox write/read boundaries, actual agent invocations, hand-computed timing/SLO cases, and independent rescoring from saved request records.
9. Run the same starting policy, prompt and submission budget across available Claude/Codex models and the selected Mooncake workloads. Report per-workload baseline deltas and failures, keep held-out evaluation private during optimization, and identify a small pilot as a pilot rather than claiming a model ranking. Freeze the objective and tiebreaks before model runs.
10. Review the final diff and write a concise results/reproduction guide with exact commands, environment, raw artifact locations, limitations, and remaining work. Unsupported metrics remain explicitly unavailable; tell the user what blocked them.

## Constraints and decisions

- Keep changes confined to the KV eviction research directory where practical; no GPU dependencies or Rust changes are needed to run these simulator experiments.
- No automatic pushes, deployments, or paid service setup. Existing authenticated model CLIs may be used for the requested runs.
- Python scoring is deterministic; model generation is stochastic and cannot promise identical policies on rerun.
- The current TTFT formula is a cache-miss cost proxy. A serving timing model is required for the additional metrics. Neither mode is measured GPU latency. Do not describe arrival-rate arithmetic as achieved throughput.
- Keep commands separately readable in documentation; do not hide the workflow in long shell pipelines.
- Do not give models the test traces or final scores while they tune. If local CLI permissions cannot enforce a boundary, document it and fail clearly rather than claiming a secure sandbox.
- Disclose failures and modeling gaps promptly. An unavailable or unsupported metric must be marked unavailable with its reason; never invent plausible values, silently substitute a weaker method, or present an unverified result as a reproduction.

## Metrics and validity requirements

Requested metrics include mean and p95 simulated TTFT, mean and p95 simulated inter-token latency (ITL), and goodput under an explicit SLO, in addition to cache reuse and recomputation.

The original simulator does not model a serving queue, prefill/decode execution, batching, or output-token timestamps. Its TTFT is a fixed cache-miss formula; its `sim_throughput_rps` is the offered arrival rate, not achieved throughput. It cannot currently produce legitimate ITL or SLO goodput. Preserve the original baseline mode, but do not attach invented decode results to it.

Before reporting serving metrics:

- Add an event-based serving model with explicit arrival, scheduling, prefill, decode, completion, active KV allocation, and cache retention events. Record batching, memory limits, and any offload assumptions. Timing curves must have a named source, units, hardware/model identity, and calibration evidence. Uncalibrated scenarios must be labeled as such.
- TTFT is first output-token time minus request arrival time, including queueing. ITL is the gap between consecutive output tokens. Save enough per-request/token timing data for independent recomputation; state whether pooled ITL percentiles or per-request aggregates are used. Requests with fewer than two output tokens have no ITL and must have explicit eligibility handling.
- Define a successful request as meeting both the recorded TTFT threshold and recorded ITL criterion, completing without error. Report SLO attainment and request goodput separately: qualifying completed requests divided by the documented replay observation duration. Keep failures, timeouts, and unfinished requests visible; do not improve scores by dropping them. Report offered load and achieved throughput separately.
- Choose and freeze SLO thresholds before held-out runs based on the intended workload/hardware. Save the thresholds and their rationale; run sensitivity checks rather than choosing thresholds that favor a policy. There is no universal reasonable SLO independent of model, hardware, context length, and workload.
- Compare policies on identical trace windows, cache token budgets, arrival settings, timing models, and SLOs. Select using tuning data only. Preserve cold/warm-start settings, random seeds, normalization, and all policy source hashes.
- Validate tiny hand-calculable cases for cache hits/misses, queueing, token emission, TTL expiry, SLO boundaries, and failure accounting. Cross-check aggregate metrics against the saved timing records, and calibrate/compare against real engine runs before claiming production-predictive results.

### Exact reporting conventions

| Metric | Definition / reporting rule |
| --- | --- |
| Mean/p95 simulated TTFT | Per-request first output-token time minus arrival, including queueing, prefill and first-token work. Aggregate one TTFT per eligible request. |
| Mean/p95 simulated ITL | Differences between consecutive output-token timestamps, excluding TTFT. Aggregate actual simulated gaps across requests and state that longer outputs contribute more samples. Also retain each request's mean/p95 ITL. TPOT, a per-request average, is not a p95 ITL. |
| Simulated goodput (requests/s) | Completed requests meeting both latency SLOs divided by simulated measurement duration. For the initial finite-window replay, use the first scored arrival through the last scored completion, including drain time. Record cohort, both boundaries and the denominator. Never divide by simulator wall time or equate this with incoming request rate. If requests are unfinished, record the simulation stop time and the incomplete run status. |
| SLO attainment | Good requests / all scored requests. Failed, timed-out and unfinished requests cannot pass. Never drop failures to improve the ratio. |
| Recomputed input tokens | Input work needed after the first uncached prefix block, accounting for the partial final block. Lower is better. |
| Token cache-hit rate | Reused input tokens / input tokens considered. Record counts and whether partial blocks are cacheable. Higher is better. |
| Evictions | Blocks removed; diagnostic only. Record block size. |
| Policy validity | Invalid IDs, exceptions, timeouts, budget violations and fallback counts. A broken policy must not receive successful scores from a silent LRU fallback. |
| Agent effort | Submitted candidates, elapsed model time, exact resolved model, and available token/cost usage. Subscription API-equivalent cost estimates are not actual charges. |

Provisional interactive SLO: TTFT <= 1,000 ms **and** per-request p95 ITL <= 50 ms. These are proposed experiment targets, not a universal standard. Validate their relevance against the intended timing profile and baseline, then freeze them before model-policy comparisons. If every policy passes or fails, report a non-discriminating SLO. Do not move the thresholds after inspecting candidate results to manufacture a gain. Any tighter/looser sensitivity checks must be predeclared and all reported.

One-output-token requests have TTFT but no ITL samples; the ITL criterion is not applicable and TTFT alone determines their latency pass. Zero-output records cannot produce TTFT: retain their count and declare eligibility treatment before scoring. Never insert zero-valued ITLs for missing samples. Document and use one percentile method, including in offline rescoring.

Cache capacity is specified **in tokens**: the baseline uses 16-token blocks while Mooncake uses 512-token blocks. The proposed real-trace default is 131,072 tokens (256 Mooncake blocks). Fixed block counts across different block sizes are not equal memory budgets.

For serving experiments, select by tuning goodput; break ties by lower mean TTFT, then retain the earlier submission. Report mean/p95 TTFT and ITL even when unchanged, with cache metrics as diagnostics. Freeze these rules before optimization. Until serving metrics pass validation, report cache experiments only and mark ITL/goodput unavailable rather than claiming the serving comparison is complete.

### Validity gates and disclosure

- Label the existing formula `legacy_cache_proxy` for reproduction. Keep its numerical results separate from event-model results. Record whether each new timing profile is assumed, calibrated or measured, with parameters and provenance; a validated simulator with assumed parameters is not a validated hardware prediction.
- Keep active and inactive KV distinct; policies cannot evict in-use blocks. State scheduler, batching, decode growth, capacity limits and deferred offload/preemption behavior. Do not add unsupported complexity merely to make ITL vary.
- Save per-request arrival, first/last-token times, output count, ITL gap data or an exact compact representation, cache counts, completion/error state and SLO pass/fail reason. Independently rescore these records without invoking an agent.
- Hand-check an uncached request, reused prefix, overlapping arrivals/queueing, one-token output, overloaded replay, and requests exactly at/just beyond the SLO boundaries. Changing the SLO should change classification without changing token timestamps. Check monotone clocks, no negative latency, token accounting and memory capacity.
- If the decode model makes ITL constant or unaffected by eviction, report that fact and the model limitation. Never invent an ITL improvement.
- The trusted controller owns scoring, clocks, evaluation inputs and immutable logs. Validate filesystem read restrictions as well as write restrictions; a policy/agent must not inspect test traces or evaluator internals.
- Reset policy/cache/queue state between independent tuning and evaluation runs. Record exact warmup and scoring windows. Public time-series windows can share prefixes; do not claim session independence if the trace does not establish it.
- Preserve failed trials, transcripts, invalid policies and interrupted-run status. No silent model substitution, metric redefinition, fallback policy, changed trace window or hidden scoring correction. Missing data is unavailable/null with a reason, never a plausible-looking zero.
- Tell the user promptly about failed reproductions, unsupported timing claims, trace conversion errors, broken isolation, unavailable models, suspicious improvements and non-discriminating SLOs. Preserve evidence, repair the issue and rerun affected checks before accepting the result.

Reference for the general goodput definition: https://docs.nvidia.com/aiperf/latest/tutorials/metrics-analysis/benchmark-goodput-with-ai-perf. Our chosen per-request ITL percentile and finite-run measurement horizon are explicit experiment conventions, not a claim of exact compatibility with another benchmarking tool.

## Selected traces and simple loading

| Workload | Purpose | Source |
| --- | --- | --- |
| Existing synthetic generator | Exact baseline reproduction and fast checks; current tuning seed 42 / evaluation seed 99, 312 requests each | Fork at the pinned baseline |
| Mooncake conversation | Real conversation traffic with reusable prefixes; 12,031 requests in the published release | `FAST25-release/traces/conversation_trace.jsonl` |
| Mooncake tool/agent | Real tool/agent traffic with a different reuse pattern; 23,608 requests in the published release | `FAST25-release/traces/toolagent_trace.jsonl` |

Primary release documentation: https://github.com/kvcache-ai/Mooncake/blob/main/FAST25-release/README.md. Resolve immutable revisions before downloading. Store exact source URLs, license evidence, SHA-256, actual request counts and time ranges in persistent trace manifests. Verify counts from downloaded bytes.

Mooncake provides `timestamp` (milliseconds), `input_length`, `output_length`, and ordered cumulative `hash_ids` over 512-token blocks. It supplies no raw text, token timestamps or GPU timing. Preserve shared hash identities and prefix relationships; do not invent tokens or infer reusable content from lengths alone. Convert milliseconds to seconds explicitly.

Use a versioned JSONL block-request representation: metadata declares block size/provenance; requests contain ID, arrival time, input/output lengths, and ordered block identities. Add a small Mooncake adapter. Validate finite/monotone times, input/output lengths, hash-count consistency, duplicate IDs and partial blocks; errors identify file and line. Record contiguous tuning/evaluation windows and any arrival-rate scaling before optimization. Do not shuffle time-series requests or provide holdout inputs/scores to the agent.

## Proposed user commands

These are the command interfaces to build; only the existing `submit.py` command currently works. Execute them separately from the repository root. Model availability is checked before starting; exact resolved model IDs and effort settings are logged.

```bash
python3 research/kv-eviction/sandbox/submit.py
```

```bash
python3 research/kv-eviction/experiment.py fetch-traces
```

```bash
python3 research/kv-eviction/experiment.py baseline \
  --trace mooncake-conversation \
  --cache-tokens 131072 \
  --timing-profile research/kv-eviction/profiles/interactive.json \
  --ttft-slo-ms 1000 --itl-slo-ms 50 \
  --output experiments/conversation-baselines
```

```bash
python3 research/kv-eviction/experiment.py run \
  --agent codex --model gpt-6.1-sol \
  --trace mooncake-conversation \
  --cache-tokens 131072 \
  --timing-profile research/kv-eviction/profiles/interactive.json \
  --ttft-slo-ms 1000 --itl-slo-ms 50 \
  --submissions 5 \
  --output experiments/conversation-codex
```

```bash
python3 research/kv-eviction/experiment.py run \
  --agent claude --model sonnet \
  --trace mooncake-conversation \
  --cache-tokens 131072 \
  --timing-profile research/kv-eviction/profiles/interactive.json \
  --ttft-slo-ms 1000 --itl-slo-ms 50 \
  --submissions 5 \
  --output experiments/conversation-claude
```

The controller launches the sandboxed agent, obtains and archives a policy, scores tuning data, returns feedback and repeats within the submission/time budget. It selects from tuning results and only then runs the holdout. The trusted controller may execute evaluation rather than expose evaluator commands/data to the agent; this preserves the requested one-command experience while enforcing isolation.

## Saved output and comparison protocol

```text
experiments/conversation-codex/
  manifest.json              # Commit/dirty-source digest, model/CLI versions,
                             # commands, trace hashes, seeds/windows, budgets,
                             # cache size, timing assumptions and SLO
  prompt.md
  baselines.json             # LRU and LRU with leaf-first tiebreak
  submissions/
    001/
      policy.py              # Exact submitted source + digest
      tuning.json            # Metrics or explicit failure/reason
      requests.jsonl         # Auditable per-request/token timing
      agent.jsonl            # Complete model/tool transcript
      stderr.txt
    002/...
  selected-policy.py
  evaluation.json            # Selected-policy and baseline holdout scores
  evaluation-requests.jsonl  # Raw holdout records, with policy identifiers
  summary.md
```

Never overwrite existing run directories or same-second submissions. Keep all submissions, including duplicates and invalid policies, in order. Preserve incomplete-run artifacts and status. Store the full timing/SLO settings rather than only a path to a mutable profile. New ignored results are not automatically uploaded or saved by Git: document retrieval/export explicitly and keep this plan plus the final report in durable Markdown outside ignored result directories.

Freeze prompt, initial LRU policy, trace windows, cache capacity, load, timing profile, SLO, submission count and timeout limits across models. Keep leaf-first LRU as a separately named reference. Initial pilot: five submissions per run across the synthetic baseline and the two Mooncake workloads, with at least two available models per CLI if account access permits. Record all attempted runs and failures. Repeat independent runs where budget permits; do not claim a reliable model ranking from one stochastic trial. A saved policy must be rescorable without making a model call.

## Continuum reproduction assessment

Assumed reference: Continuum / Continnum, *Efficient and Robust Multi-Turn LLM Agent Scheduling with KV Cache Time-to-Live*, arXiv:2511.02230v7. Pin the paper version because it differs from the earlier preview implementation.

Sources:

- Paper: https://arxiv.org/html/2511.02230v7
- Preview implementation: https://github.com/Hanchenli/vllm-continuum, inspected head 316a58794a6ff86b216e579b74fd56ed0c5a911f.
- The preview README explicitly says it provides Continuum-style scheduling **without the estimation in the paper**. Running it is not sufficient to claim a reproduction of the full paper algorithm.

Required additions for a simulator implementation:

1. Program-aware traces: program ID, turn/dependency order, output length, tool identity, observed tool duration, termination, and prefix identities or tokens. Plain Mooncake JSONL has timing/length/hash fields but does not supply all these program/tool labels. Do not infer tool execution time by subtracting request arrivals or treat hash overlap as a reliable program ID.
2. Closed-loop replay: a dependent turn becomes ready after its predecessor completes plus its tool delay. Fixed absolute request arrivals cannot faithfully represent feedback from scheduling improvements into subsequent turns. Models may see the next tool identity if available at the decision time, but never the future realized duration or remaining turns as an oracle.
3. A serving scheduler and memory model: active versus inactive cache, program-level FCFS, decode-time cache growth, prefill/reload costs, TTL pins/expiry/unpinning, returning-request priority, and memory-pressure/deadlock handling.
4. The paper's TTL estimator, including online per-tool duration histories, cold-start behavior, empirical duration distributions, queue-delay estimates, and memory opportunity costs. Keep fixed-TTL and full-estimator variants separate.
5. Ablations: request FCFS with baseline cache behavior; program FCFS alone; program FCFS with fixed TTL; program FCFS with estimated TTL. Compare job completion time and queue delay as well as TTFT, ITL, cache reuse, and SLO goodput. Test long/failed tools and saturated memory.

Reproduction levels must remain distinct:

- Algorithm simulation: verifies a documented implementation under explicit timing assumptions; does not reproduce published GPU performance.
- Preview-code replication: run pinned upstream vLLM baseline and Continuum preview on the same GPU/model and agent workload. The public README describes an example with Llama-3.1-70B on four H100 GPUs; start with a smaller supported configuration only as an explicitly different experiment.
- Paper-result reproduction: needs the full estimator, exact workload artifacts and versions, matching model/hardware/settings, profiling, load sweeps, and repeated measurements. Verify availability of the paper's complete traces and scripts before promising identical figures. Production/private-testbed results cannot be assumed reproducible from public summary JSON files.

For an eventual Dynamo integration, establish the reference behavior in the vLLM backend first; a block-level inactive-pool callback alone cannot control program admission, scheduling priority, or TTL pinning. Do not begin a full engine port as part of answering the feasibility question.

## Progress

- [x] Confirmed current fork head and inspected evaluator, policy runner, synthetic trace and stored results.
- [x] Found local Codex and Claude Code executables and verified both existing subscription logins.
- [x] Recorded reviewed command/output design, Mooncake trace selection, mean/p95 TTFT and ITL definitions, SLO goodput, and explicit validity/disclosure gates.
- [ ] Create checkout/branch and save plan there.
- [ ] Reproduce and archive original results.
- [ ] Implement trace loading and experiment runner.
- [ ] Run objective checks and actual model comparisons.
- [ ] Save report and final review.

## Evidence and deviations

Append concrete observations here as work proceeds, especially unavailable models, authentication failures, scope adjustments, and checks that failed.

- A shallow fork checkout is available at `dynamo-kv-research`; no experiment implementation has been added there yet. An unnecessary full-history download was stopped. The user requested a command/output review before implementation continued.
- Selected initial public workloads are Mooncake conversation and tool/agent traces, plus the existing synthetic baseline for reproduction.
- The requested ITL/goodput metrics expose a real limitation of the existing cache-only simulator. Address the serving model before publishing these metrics, or explicitly leave them unavailable.
- The current evaluator exposes evaluation scores during iteration and reuses one policy instance across tuning/evaluation. The new controller must hide holdout feedback and prevent unintended cross-split policy-state leakage.
- The initial inspection reran the current baseline twice with matching scoring metrics: tuning hit rate 0.7549 / mean TTFT proxy 60.66 ms / 853 evictions; evaluation hit rate 0.7577 / mean TTFT proxy 60.54 ms / 840 evictions. These were temporary inspection runs, not yet the durable reproduction artifacts promised above.
- Proposed commands, timing profiles, new trace loaders, persistent run archives and model comparisons are not yet implemented or validated. Implementation remains paused for the user's design review; do not present the plan as an existing working feature.
