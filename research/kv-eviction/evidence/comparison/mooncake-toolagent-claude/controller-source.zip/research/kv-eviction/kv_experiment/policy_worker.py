"""Runs inside the policy container; the host scorer never imports policy code."""

import importlib.util
import json
import sys

spec = importlib.util.spec_from_file_location("policy", "/submission/policy.py")
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
policy = module.EvictionPolicy()
print(json.dumps({"status": "ready"}), flush=True)
for line in sys.stdin:
    candidates = json.loads(line)
    victim = policy.select_victim(candidates)
    if type(victim) is not int or victim not in {row["block_id"] for row in candidates}:
        raise ValueError("select_victim must return an integer candidate block_id")
    print(json.dumps({"victim_id": victim}), flush=True)
